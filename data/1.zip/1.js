var page     = require('showtime/page');
var service  = require('showtime/service');
var settings = require('showtime/settings');
var http     = require('showtime/http');

var plugin  = JSON.parse(Plugin.manifest);
var logo    = Plugin.path + plugin.icon;
var bg      = Plugin.path + 'bg.png';
var favIcon = Plugin.path + 'favorites.png';

var MAIN_URL = 'https://gist.githubusercontent.com/milotobias/1c19cf902445b6d7c090588d2aec6fd5/raw/9cd4b462e62a720cb9c3602af3fbd0d508c0bf93/1.txt';
var SEARCH_INDEX = [];

function buildSearchIndex(){

  SEARCH_INDEX = [];

  var raw = fetchText(MAIN_URL);

  if(!raw) return;

  var items = parseM3U(raw);

  for(var i=0;i<items.length;i++){

    var it = items[i];

    if(isSubmenu(it.url)){

      var subraw = fetchText(it.url);

      if(!subraw) continue;

      var subs = parseM3U(subraw);

      for(var j=0;j<subs.length;j++){

        SEARCH_INDEX.push({
          title: subs[j].title,
          url: subs[j].url,
          icon: subs[j].icon
        });

      }

    } else {

      SEARCH_INDEX.push({
        title: it.title,
        url: it.url,
        icon: it.icon
      });

    }

  }

}
var UA = 'Mozilla/5.0 (SMART-TV; Linux; Tizen 5.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/56.0.2924.0 TV Safari/537.36';

var cache = {

  data: {},
  ttl: 24 * 60 * 60 * 1000,

  load: function(){
    try{
      this.data = JSON.parse(Plugin.store.ps3flix_cache || "{}");
    }catch(e){
      this.data = {};
    }
  },

  save: function(){
    try{
      Plugin.store.ps3flix_cache = JSON.stringify(this.data);
    }catch(e){}
  },

  get: function(url){

    var e = this.data[url];

    if(e && (Date.now() - e.t) < this.ttl)
      return e.d;

    return null;
  },

  set: function(url,data){

    this.data[url] = {
      d: data,
      t: Date.now()
    };

    this.save();
  },

  clear: function(){
    this.data = {};
    this.save();
  }

};

cache.load();
var favorites = {
  _list: null,
  _load: function() {
    if (this._list !== null) return;
    try {
      var raw = Plugin.store.ps3flix_favs;
      this._list = (raw && raw !== '') ? JSON.parse(raw) : [];
    } catch(e) { this._list = []; }
  },
  _save: function() {
    try { Plugin.store.ps3flix_favs = JSON.stringify(this._list); } catch(e) {}
  },
  has: function(url) {
    this._load();
    for (var i = 0; i < this._list.length; i++) {
      if (this._list[i].url === url) return true;
    }
    return false;
  },
  add: function(item) {
    this._load();
    if (!this.has(item.url)) { this._list.push(item); this._save(); }
  },
  remove: function(url) {
    this._load();
    for (var i = 0; i < this._list.length; i++) {
      if (this._list[i].url === url) { this._list.splice(i, 1); this._save(); return; }
    }
  },
  getAll: function() { this._load(); return this._list.slice(); },
  clear: function() { this._list = []; this._save(); }
};

function notify(msg) {
  try { var popup = require('native/popup'); popup.notify(msg, 3); } catch(e) {}
}

settings.globalSettings(plugin.id, plugin.title, logo, 'VIDEOTECA');

settings.createDivider('Contenido');

settings.createMultiOpt('previewCount', 'Previews por seccion en el menu principal', [
  ['0', 'Desactivado', true],
  ['2', '2 items'],
  ['4', '4 items'],
  ['6', '6 items'],
  ['9', '9 items']
], function(v) {
  service.previewCount = parseInt(v);
});

settings.createDivider('Mantenimiento');

settings.createAction('clearCache', 'Limpiar Cache', function() {
  cache.clear();
  notify('Cache limpiado.');
});

settings.createAction('clearFavs', 'Borrar todos los Favoritos', function() {
  favorites.clear();
  notify('Favoritos borrados.');
});

settings.createDivider('');
settings.createInfo('ver', 'Version ' + plugin.version + '  |  VIDEOTECA');

RichText = function(x) { this.str = x.toString(); };
RichText.prototype.toRichString = function() { return this.str; };

function colored(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
}

function setPageHeader(pg, title) {
  if (pg.metadata) {
    pg.metadata.title      = title;
    pg.metadata.logo       = logo;
    pg.metadata.background = bg;
  }
  pg.type     = 'directory';
  pg.contents = 'items';
  pg.loading  = false;
}

function cleanTitle(t) {
  if (!t) return '';
  return t.replace(/^[=\s]*->\s*/, '').trim();
}

function fetchText(url) {
  try {
    var cached = cache.get(url);
    if (cached) return cached;
    var data = http.request(url, { headers: { 'User-Agent': UA }, timeout: 15 }).toString();
    if (data) cache.set(url, data);
    return data || '';
  } catch(e) { return ''; }
}
function fetchTextParallel(urls, callback) {

  var results = {};
  var remaining = urls.length;

  if (remaining === 0) {
    callback(results);
    return;
  }

  for (var i = 0; i < urls.length; i++) {

    (function(url){

      var cached = cache.get(url);

      if (cached) {
        results[url] = cached;
        if (--remaining === 0)
          callback(results);
        return;
      }

      http.request(url, {
        headers: { 'User-Agent': UA },
        timeout: 15
      }, function(err, resp){

        var data = '';

        if (!err && resp)
          data = resp.toString();

        if (data)
          cache.set(url, data);

        results[url] = data;

        if (--remaining === 0)
          callback(results);

      });

    })(urls[i]);

  }
}

function isSubmenu(url) {
  var u = url.split('#')[0].toLowerCase();
  return /[=\/][^=\/]+\.m3u(\?|&|$)/.test(u) || u.slice(-4) === '.m3u';
}

function appendHeaderSep(pg) {
  pg.appendItem('', 'separator', {
    title: new RichText(
      colored('\u2726 ', 'FFD700') +
      colored(' \u2726 ', 'FF6600') +
      colored(' \u2726', 'FFD700')
    )
  });
}

function appendFooterSep(pg) {
  pg.appendItem('', 'separator', {
    title: new RichText(
      colored('\u2726 ', 'FFD700') +
      colored(' \u2726', 'FFD700')
    )
  });
}

function parseM3U(raw){

  var items = [];

  if(!raw) return items;

  var lines = raw.split('\n');

  var title = '';
  var icon = '';

  for(var i=0;i<lines.length;i++){

    var line = lines[i].trim();

    if(!line) continue;

    if(line.indexOf('#EXTINF') === 0){

      var logoMatch = /tvg-logo="([^"]+)"/.exec(line);
      icon = logoMatch ? logoMatch[1] : '';

      var titleMatch = line.substring(line.indexOf(',')+1);
      title = cleanTitle(titleMatch);

    }

    else if(line[0] !== '#' && line.indexOf('://') !== -1){

      items.push({
        title: title || line,
        url: line,
        icon: icon
      });

      title = '';
      icon = '';

    }

  }

  return items;

}

function appendVideo(pg, item) {

  var u = item.url.toLowerCase();

  var src = item.url;

  if(u.indexOf('.m3u8') !== -1)
    src = 'hls:' + item.url;

  var link = 'videoparams:' + JSON.stringify({

    title: item.title,
    icon: item.icon || void 0,

    sources: [{
      url: src,
      buffering: true
    }],

    no_fs_scan: true,
    no_subtitle_scan: true,
    canonicalUrl: item.url,
    imdbid: null

  });

  var it = pg.appendItem(link, 'video', {
    title: new RichText(item.title),
                         icon: item.icon || null
  });

}

function appendSubmenuItem(pg, item) {
  var it = pg.appendItem(
    plugin.id + ':submenu:' + encodeURIComponent(item.url) + ':' + encodeURIComponent(item.title),
    'directory',
    { title: new RichText(item.title), icon: item.icon || null }
  );
  (function(entry) {
    if (favorites.has(entry.url)) {
      it.addOptAction('Quitar de Favoritos', function() {
        favorites.remove(entry.url);
        notify('Quitado de favoritos: ' + entry.title);
      });
    } else {
      it.addOptAction('Agregar a Favoritos', function() {
        favorites.add(entry);
        notify('Agregado a favoritos: ' + entry.title);
      });
    }
  })({ url: item.url, title: item.title, icon: item.icon || '', isSub: true });
}

function appendAnyItem(pg, item) {
  if (isSubmenu(item.url)) appendSubmenuItem(pg, item);
  else appendVideo(pg, item);
}

function renderSection(pg, item) {
  var count    = service.previewCount || 0;
  var raw      = count > 0 ? fetchText(item.url) : null;
  var children = raw ? parseM3U(raw) : [];

  var displayTitle = children.length > 0
    ? item.title + '  (' + children.length + ')'
    : item.title;

  var it = pg.appendItem(
    plugin.id + ':submenu:' + encodeURIComponent(item.url) + ':' + encodeURIComponent(item.title),
    'directory',
    { title: new RichText(colored(displayTitle, 'FFD700')), icon: item.icon || null }
  );
  (function(entry) {
    if (favorites.has(entry.url)) {
      it.addOptAction('Quitar de Favoritos', function() {
        favorites.remove(entry.url);
        notify('Quitado de favoritos: ' + entry.title);
      });
    } else {
      it.addOptAction('Agregar a Favoritos', function() {
        favorites.add(entry);
        notify('Agregado a favoritos: ' + entry.title);
      });
    }
  })({ url: item.url, title: item.title, icon: item.icon || '', isSub: true });

  if (count <= 0 || children.length === 0) return;
  var recent = children.slice(-count);
  for (var j = 0; j < recent.length; j++) appendAnyItem(pg, recent[j]);
}

function searchSmart(pg, url, label, queryLow, depth, counter) {
  if (depth > 5) return;
  var raw = fetchText(url);
  if (!raw) return;
  var items = parseM3U(raw);
  if (!items || items.length === 0) return;

  var hasSubMenus = false;
  for (var k = 0; k < items.length; k++) {
    if (isSubmenu(items[k].url)) { hasSubMenus = true; break; }
  }

  if (depth > 0 && !hasSubMenus) {
    if (label.toLowerCase().indexOf(queryLow) >= 0) return;
    var leafHits = [];
    for (var li = 0; li < items.length; li++) {
      if (items[li].title.toLowerCase().indexOf(queryLow) >= 0) leafHits.push(items[li]);
    }
    if (leafHits.length > 0) {
      pg.appendItem('', 'separator', {
        title: new RichText(
          colored('\u25B6 ', 'FF6600') +
          colored(label.toUpperCase(), 'FFD700') +
          colored('  ' + leafHits.length + ' resultado' + (leafHits.length !== 1 ? 's' : ''), 'AAAAAA')
        )
      });
      for (var lj = 0; lj < leafHits.length; lj++) {
        appendAnyItem(pg, leafHits[lj]);
        counter.n++;
      }
    }
    return;
  }

  var hits = [];
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    var match = it.title.toLowerCase().indexOf(queryLow) >= 0;
    if (isSubmenu(it.url)) {
      if (match) hits.push(it);
      searchSmart(pg, it.url, it.title, queryLow, depth + 1, counter);
    } else {
      if (match) hits.push(it);
    }
  }

  if (hits.length > 0) {
    pg.appendItem('', 'separator', {
      title: new RichText(
        colored('\u25B6 ', 'FF6600') +
        colored(label.toUpperCase(), 'FFD700') +
        colored('  ' + hits.length + ' resultado' + (hits.length !== 1 ? 's' : ''), 'AAAAAA')
      )
    });
    for (var v = 0; v < hits.length; v++) {
      appendAnyItem(pg, hits[v]);
      counter.n++;
    }
  }
}

function appendGlobalSearch(pg) {
  pg.appendItem('', 'separator', {
    title: new RichText(colored('\u2315 BUSCAR EN TODO EL CONTENIDO', 'AAAAAA'))
  });
  pg.appendItem(plugin.id + ':searchglobal:', 'search', {
    title: 'Buscar en todo el contenido...'
  });
}

function appendSectionSearch(pg, sectionUrl, sectionTitle) {
  pg.appendItem('', 'separator', {
    title: new RichText(colored('\u2315 BUSCAR EN ESTA SECCION', 'AAAAAA'))
  });
  pg.appendItem(
    plugin.id + ':searchsection:' + encodeURIComponent(sectionUrl) + ':',
    'search',
    { title: 'Buscar en ' + sectionTitle + '...' }
  );
}

new page.Route(plugin.id + ':favorites', function(pg) {
  setPageHeader(pg, 'Mis Favoritos');
  pg.loading = true;

  appendHeaderSep(pg);
  pg.appendItem('', 'separator', {
    title: new RichText(colored('MIS FAVORITOS', 'FF4466'))
  });
  pg.appendItem('', 'separator', { title: '' });

  var list = favorites.getAll();

  if (list.length === 0) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Aun no tienes favoritos guardados.', 'AAAAAA'))
    });
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Selecciona un item y usa "Agregar a Favoritos" del menu contextual.', '888888'))
    });
  } else {
    var subs = [], vids = [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].isSub) subs.push(list[i]);
      else vids.push(list[i]);
    }
    if (subs.length > 0) {
      pg.appendItem('', 'separator', {
        title: new RichText(
          colored('CARPETAS', 'FFD700') +
          colored('  ' + subs.length, 'AAAAAA')
        )
      });
      for (var s = 0; s < subs.length; s++) appendAnyItem(pg, subs[s]);
    }
    if (vids.length > 0) {
      pg.appendItem('', 'separator', {
        title: new RichText(
          colored('VIDEOS', 'FFD700') +
          colored('  ' + vids.length, 'AAAAAA')
        )
      });
      pg.model.contents = 'grid';
      pg.model.metadata = 'video';
      for (var v = 0; v < vids.length; v++) appendAnyItem(pg, vids[v]);
    }
  }

  appendFooterSep(pg);
  pg.metadata.title = 'Favoritos (' + list.length + ')';
  pg.loading = false;
});

new page.Route(plugin.id + ':searchglobal:(.*)', function(pg, query) {
  query = decodeURIComponent(query || '').trim();
  setPageHeader(pg, query ? 'Buscando: ' + query : 'Buscar');
  pg.loading = true;

  appendHeaderSep(pg);
  pg.appendItem(plugin.id + ':searchglobal:', 'search', {
    title: 'Buscar en todo el contenido...'
  });
  pg.appendItem('', 'separator', { title: '' });

  if (!query) {
    pg.appendItem('', 'separator', { title: 'Escribe algo para buscar...' });
    pg.loading = false;
    return;
  }

  try {
    var queryLow = query.toLowerCase();
    var results = 0;

    for (var i = 0; i < SEARCH_INDEX.length; i++) {

      var it = SEARCH_INDEX[i];

      if (it.title.toLowerCase().indexOf(queryLow) >= 0) {

        appendAnyItem(pg, it);

        results++;

      }

    }

    if (results === 0) {

      pg.appendItem('', 'separator', {
        title: new RichText(colored('Sin resultados para: "' + query + '"', 'FF4444'))
      });

      pg.metadata.title = 'Sin resultados: ' + query;

    } else {

      pg.metadata.title = '"' + query + '"  ' + results + ' resultados';

    }
  } catch(e) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Error durante la busqueda: ' + e, 'FF4444'))
    });
    pg.metadata.title = 'Error en busqueda';
  }

  appendFooterSep(pg);
  pg.loading = false;
});

new page.Route(plugin.id + ':searchsection:(.*):(.*)', function(pg, encodedUrl, query) {
  var sectionUrl = decodeURIComponent(encodedUrl);
  query = decodeURIComponent(query || '').trim();
  setPageHeader(pg, query ? 'Buscando: ' + query : 'Buscar');
  pg.loading = true;

  appendHeaderSep(pg);
  pg.appendItem(
    plugin.id + ':searchsection:' + encodeURIComponent(sectionUrl) + ':',
    'search',
    { title: 'Buscar en esta seccion...' }
  );
  pg.appendItem('', 'separator', { title: '' });

  if (!query) {
    pg.appendItem('', 'separator', { title: 'Escribe algo para buscar...' });
    pg.loading = false;
    return;
  }

  try {
    var queryLow = query.toLowerCase();
    var counter  = { n: 0 };
    pg.metadata.title = 'Buscando "' + query + '"...';
    searchSmart(pg, sectionUrl, 'Resultados', queryLow, 0, counter);

    if (counter.n === 0) {
      pg.appendItem('', 'separator', {
        title: new RichText(colored('Sin resultados para: "' + query + '"', 'FF4444'))
      });
      pg.metadata.title = 'Sin resultados: ' + query;
    } else {
      pg.metadata.title = '"' + query + '"  ' + counter.n + ' resultado' + (counter.n !== 1 ? 's' : '');
    }
  } catch(e) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Error: ' + e, 'FF4444'))
    });
    pg.metadata.title = 'Error en busqueda';
  }

  appendFooterSep(pg);
  pg.loading = false;
});

new page.Route(plugin.id + ':submenu:(.*):(.*)', function(pg, encodedUrl, encodedTitle) {
  var url   = decodeURIComponent(encodedUrl);
  var title = decodeURIComponent(encodedTitle);

  setPageHeader(pg, title);
  pg.loading = true;

  appendHeaderSep(pg);
  appendSectionSearch(pg, url, title);
  pg.appendItem('', 'separator', { title: '' });

  var itemCount = 0;
  try {
    var raw = fetchText(url);
    if (!raw) { pg.error('Error al cargar: ' + title); return; }

    var items = parseM3U(raw);
    if (items.length === 0) { pg.error('El submenu esta vacio.'); return; }
    itemCount = items.length;

    var hasSubmenus = false;
    for (var k = 0; k < items.length; k++) {
      if (isSubmenu(items[k].url)) { hasSubmenus = true; break; }
    }

    if (hasSubmenus) {
      for (var i = 0; i < items.length; i++) {
        if (isSubmenu(items[i].url)) renderSection(pg, items[i]);
        else appendVideo(pg, items[i]);
      }
    } else {
      pg.model.contents = 'grid';
      pg.model.metadata = 'video';
      for (var j = 0; j < items.length; j++) appendVideo(pg, items[j]);
    }
  } catch(e) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Error: ' + e, 'FF4444'))
    });
  }

  appendFooterSep(pg);
  pg.metadata.title = title + (itemCount ? ' (' + itemCount + ')' : '');
  pg.loading = false;
});

new page.Route(plugin.id + ':start', function(pg) {
  setPageHeader(pg, plugin.title);
  pg.loading = true;

  if (SEARCH_INDEX.length === 0)
    buildSearchIndex();

  appendHeaderSep(pg);
  appendGlobalSearch(pg);

  pg.appendItem(plugin.id + ':favorites', 'directory', {
    title: new RichText(colored('Mis Favoritos', 'FF4466')),
    icon: favIcon
  });

  var favList = favorites.getAll();
  if (favList.length > 0) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('FAVORITOS RECIENTES', 'FF4466'))
    });
    var recentFavs = favList.slice(-4).reverse();
    for (var f = 0; f < recentFavs.length; f++) appendAnyItem(pg, recentFavs[f]);
  }

  pg.appendItem('', 'separator', { title: '' });

  try {
    var raw = fetchText(MAIN_URL);
    if (!raw) { pg.error('No se pudo descargar el menu principal.'); return; }

    var items = parseM3U(raw);

    if (items.length === 0) {
      pg.error('La lista principal esta vacia.');
      return;
    }

    var urls = [];

    for (var i = 0; i < items.length; i++) {
      if (isSubmenu(items[i].url))
        urls.push(items[i].url);
    }

    urls = urls.slice(0, 10);

    fetchTextParallel(urls, function(results){

      for (var i = 0; i < items.length; i++) {

        var it = items[i];

        if (isSubmenu(it.url)) {

          var subraw = results[it.url];
          var children = parseM3U(subraw);

          var displayTitle = children.length > 0
          ? it.title + ' (' + children.length + ')'
          : it.title;

          pg.appendItem(
            plugin.id + ':submenu:' + encodeURIComponent(it.url) + ':' + encodeURIComponent(it.title),
                        'directory',
                        {
                          title: new RichText(colored(displayTitle,'FFD700')),
                        icon: it.icon || null
                        }
          );

        } else {

          appendVideo(pg, it);

        }

      }

      pg.loading = false;

    });
  } catch(e) {
    pg.appendItem('', 'separator', {
      title: new RichText(colored('Error al cargar: ' + e, 'FF4444'))
    });
  }

  appendFooterSep(pg);
  pg.metadata.title = plugin.title;
  pg.loading = false;
});

service.create(plugin.title, plugin.id + ':start', 'tv', true, logo);

